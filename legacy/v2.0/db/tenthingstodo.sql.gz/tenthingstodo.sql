create table tenthingstodo
(
        user_name       char(25)        not null,       /* PK */
        diary_name      char(100)       not null,
        id              int             not null,
        description     text            null,

        primary key ( user_name, diary_name, id ),
        index tenthings_ux ( user_name, diary_name, id )
);

