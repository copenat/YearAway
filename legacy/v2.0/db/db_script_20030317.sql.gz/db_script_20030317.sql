
alter table diary_entry_photos add column (photo_order int);
update diary_entry_photos set photo_order=filename;


# Remove these hrefs
select start_date,country from diary_entry where message like "%href%"

