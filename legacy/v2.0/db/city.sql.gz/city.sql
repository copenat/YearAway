create table city
(
        country_id    char(3)  not null, /* PK */
        id            char(3)  not null, /* PK */
        capital       char(1)  not null,
        name          text     not null,
        description   text     null,
        map_ref       text     null,

        primary key ( country_id, id ),
        index city_ux ( country_id, id )
);

