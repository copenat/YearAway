use mwillett;

create table log
(
        timestamp     datetime  not null,
        title         varchar(240)      not null,
        description   text      null,
        status        int       not null,
        comment       text      null,    

        primary key ( timestamp,title ),
        index city_ux ( timestamp,title )
);

