use mwillett;

create table bookmarks
(
        user_name       char(25)        not null,
        id              int             not null,
        hyperlink       varchar(100)    not null,
        description        text                null,

        primary key ( user_name, id ),
        index bookmarks_ux ( user_name, id )
);

