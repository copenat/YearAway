use mwillett;

create table guestbook
(
        user_name       char(25)        not null,
        diary_name      char(100)       not null,
        id              int             not null,

        name                  varchar(20) not null,
        email                  varchar(50) not null,
        time_stamp        datetime    not null,
        msg                  text,
        private			int not null,

        primary key ( user_name, diary_name, name, time_stamp ),
        index guestbook_ux ( user_name, diary_name, name, time_stamp )
);

