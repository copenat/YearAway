create table trip_details
(
        user_name       char(25)        not null,       /* PK */
        diary_name      char(100)       not null,
        description	text		null,

        primary key ( user_name, diary_name ),
        index trip_planner_ux ( user_name, diary_name )

);

