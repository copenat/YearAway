create table hits
(
    time_stamp      datetime    not null,   
    user_name       char(25)    not null,   
    diary_name      char(100)   not null,  
    start_date      datetime    not null  
)


