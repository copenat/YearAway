create table continent
(
        id            char(3)  not null,  /*PK*/
        name          text     not null,
        description   text     null,
        map_ref       text     null,

        primary key ( id ),
        index continent_ux ( id )
);
