
create table trip_planner
(
        user_name       char(25)        not null,       /* PK */
        diary_name      char(100)       not null,
        id                int                not null,
        country                char(3)                not null,
        description        text                null,
        start_date        datetime        null,

        primary key ( user_name, diary_name, id ),
        index trip_planner_ux ( user_name, diary_name, id )
);


