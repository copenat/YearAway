create table tenthingstodo_links
(
        user_name       char(25)        not null,       /* PK */
        diary_name      char(100)       not null,
        id              int             not null,
        country         char(3)         null,
        location        text            null,
        start_date      datetime        null,

        primary key ( user_name, diary_name, id ),
        index ten_ux ( user_name, diary_name, id )
);


