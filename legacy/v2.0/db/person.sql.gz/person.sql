
create table person
(
        user_name       char(25)        not null,   /* PK */
        password        varchar(25)     not null,
        status_id       int             not null,
        email           text            null,
        forename        text            null,
        surname         text            null,
        ctryoforig_id   char(3)         null,
        age             smallint        null,

        sid             varchar(50)     null,
        time_stamp      datetime        null,
        last_login      datetime        null,
        gender          smallint        null,

        primary key (user_name),
        index person_ux ( user_name )
);

