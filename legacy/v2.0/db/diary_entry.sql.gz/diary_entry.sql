create table diary_entry
(
  user_name       char(25)	not null,	/* PK */
  diary_name      char(100)	not null,	/* PK */
  start_date      datetime	not null,	/* PK */
  country         char(3)         null,
  location        text		null,
  message         text		null,
  search_tags    	text		null,

  count1		int		null,
  count2		int		null,
  count3		int		null,
  section		text		null,
  status		smallint	null,
  emailsent		int			null,

  primary key (user_name, diary_name, start_date),
  index diary_entry_ux (user_name, diary_name, start_date)
);

