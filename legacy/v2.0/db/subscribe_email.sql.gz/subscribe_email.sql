create table subscribe_email
(
        user_name       char(25)        not null,
        diary_name      char(100)       not null,

        email           varchar(50) not null,
        time_stamp      datetime    not null,

        primary key ( user_name, diary_name, email ),
        index sub_ux ( user_name, diary_name, email )
);

