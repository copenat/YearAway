create table diary_entry_photos
(
  user_name       char(25)      not null,       /* PK */
  diary_name      char(100)     not null,       /* PK */
  start_date      datetime      not null,       /* PK */
  filename        int          not null,
  comment         text          not null, 
  photo           int           not null,
  photo_order	  int           not null,

  primary key (user_name,diary_name,start_date,filename),
  index diary_entry_photos_ux (user_name,diary_name,start_date,filename)
);

