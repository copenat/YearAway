create table country
(
        id             char(3)    not null,        /*PK*/
        name           char(100)  not null,
        description    text       null,
        continent_id   char(3)    not null,
        ccy            char(3)    null,
        map_ref        text       null,
        cost1          int        null,
        cost2          int        null,
        cost3          int        null,
        cost4          int        null,
        cost5          int        null,

        primary key ( id ),
        index country_ux ( id ),
        index country_cd ( continent_id )
);

